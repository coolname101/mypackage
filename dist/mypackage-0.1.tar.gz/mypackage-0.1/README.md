# This package runs a function called top_n()
This function takes in 2 arguments which are:
    items as an array or list of numerical values and;
    n as an single integer value.

# This is how the arguments are used

